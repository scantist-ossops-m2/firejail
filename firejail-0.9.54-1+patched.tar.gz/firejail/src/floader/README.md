READ ME
-------

* Run 'make'
* Add comma separated process names to ~/.loader.conf
* export LD_PRELOAD=<path>./loader.so (ideally to .bashrc)
* Run any application within shell
