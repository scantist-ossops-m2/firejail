#!/bin/sh
# This file is part of Firejail project
# Copyright (C) 2014-2020 Firejail Authors
# License GPL v2

echo "installing..."
